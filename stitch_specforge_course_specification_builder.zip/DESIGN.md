---
name: Academic Precision
colors:
  surface: '#0e1321'
  surface-dim: '#0e1321'
  surface-bright: '#343948'
  surface-container-lowest: '#090e1c'
  surface-container-low: '#161b2a'
  surface-container: '#1a1f2e'
  surface-container-high: '#252a39'
  surface-container-highest: '#303444'
  on-surface: '#dee2f6'
  on-surface-variant: '#bdc8d1'
  inverse-surface: '#dee2f6'
  inverse-on-surface: '#2b303f'
  outline: '#87929a'
  outline-variant: '#3e484f'
  surface-tint: '#7bd0ff'
  primary: '#8ed5ff'
  on-primary: '#00354a'
  primary-container: '#38bdf8'
  on-primary-container: '#004965'
  inverse-primary: '#00668a'
  secondary: '#afc6ff'
  on-secondary: '#012d6c'
  secondary-container: '#264786'
  on-secondary-container: '#99b7ff'
  tertiary: '#e1bfff'
  on-tertiary: '#490080'
  tertiary-container: '#ce9bff'
  on-tertiary-container: '#6400ac'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c4e7ff'
  primary-fixed-dim: '#7bd0ff'
  on-primary-fixed: '#001e2c'
  on-primary-fixed-variant: '#004c69'
  secondary-fixed: '#d9e2ff'
  secondary-fixed-dim: '#afc6ff'
  on-secondary-fixed: '#001944'
  on-secondary-fixed-variant: '#234584'
  tertiary-fixed: '#f0dbff'
  tertiary-fixed-dim: '#ddb7ff'
  on-tertiary-fixed: '#2c0051'
  on-tertiary-fixed-variant: '#6900b3'
  background: '#0e1321'
  on-background: '#dee2f6'
  surface-variant: '#303444'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.02em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
    letterSpacing: -0.015em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
    letterSpacing: -0.011em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
    letterSpacing: -0.006em
  body-sm:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.04em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
The design system combines the rigorous authority of traditional higher education accreditation with the razor-sharp velocity of modern developer and AI platforms. Targeted at academic deans, department chairs, syllabus review committees, and accreditation leads, the interface instills confidence through exacting precision, deliberate information hierarchy, and calm focus. 

The aesthetic is Modern Technical Minimalism infused with Luminescent Dark/Glassmorphic accents—reminiscent of Linear and Vercel. Surfaces are deep, layered slate and navy fields illuminated by targeted electric cyan and violet beams, suggesting computation occurring beneath deep institutional foundations. Interfaces maintain clean structural grids, razor-thin borders with dynamic gradient glows, and dense micro-typographic telemetry designed for multi-tier syllabus mapping, NBA criteria matrices, and Bloom's Taxonomy analytics.

## Colors
The system employs an authoritative deep palette anchored by rich nocturnal slates and university navy tones, juxtaposed with high-voltage synthetic accents:

- **Primary (`#38bdf8` - Electric Cyan):** The operational beacon. Used for active node connections, current step trackers, critical interactive buttons, and AI-driven generation states.
- **Secondary (`#1a3d7c` - University Navy):** The institutional core. Expressed through elevated structural panels, inner card surfaces, table headers, and accreditation stamp containers.
- **Tertiary (`#a855f7` - Synthetic Violet):** The analytical indicator. Reserved for machine intelligence insights, automated syllabus mapping, and higher-order cognitive taxonomy tiers (Synthesis/Evaluation).
- **Neutral (`#0a0f1d` - Deep Void Slate):** Canvas background. Supports nested tiers of dark slate (`#0f172a` for secondary containers, `#111827` for popovers and flyout panels).

### Functional Semantic Palette
- **Bloom Taxonomy Scale:**
  - *Remembering / Understanding:* Slate Cyan (`#0284c7`)
  - *Applying / Analyzing:* Vibrant Blue (`#2563eb`)
  - *Evaluating / Creating:* Violet Flare (`#9333ea`)
- **Accreditation Status:**
  - *Compliant (NBA Validated):* Emerald Pulse (`#10b981`)
  - *Deficiency / Pending Review:* Amber Alert (`#f59e0b`)
  - *Non-Compliant:* Crimson Core (`#ef4444`)

## Typography
Typographic scale balances geometric structural titles (Plus Jakarta Sans) with dense, hyper-legible neutral body text (Inter). JetBrains Mono is designated for programmatic accreditation criteria codes (e.g., `NBA.CRITERION.3.2.1`), course codes, and formula calculations.

All headlines utilize tight negative tracking to maintain a clean, compact aesthetic. Label tokens strictly mandate medium or semi-bold weights for rapid legibility in high-density matrix grids and taxonomy tags.

## Layout & Spacing
The layout follows a fluid-column structural grid system built for data density and spatial clarity:
- **Desktop (1280px+):** 12-column layout with fixed 280px left activity rail for accreditation taxonomy, 1.5rem gutters, and 2rem page borders.
- **Tablet (768px - 1279px):** 8-column layout with a collapsible sidebar drawer and 1.25rem gutters.
- **Mobile (<768px):** 4-column fluid layout with strict 1rem edge margins. Dense matrix views collapse into vertical stacked accordions.

Layout rhythm adheres strictly to an 8px base grid, using `space-xs` (4px) and `space-sm` (8px) for micro-alignments inside data capsules, chips, and table cells, scaling to `space-xl` (40px) to distinguish modular course modules.

## Elevation & Depth
Depth is constructed through optical transparency, stacked luminance, and localized edge lighting:

- **Base Layer (Ground):** `#0a0f1d` solid void background.
- **Level 1 (Card & Module Canvas):** Semi-transparent `#0f172a` tinted with 70% opacity, backed by a `backdrop-filter: blur(16px)` and a subtle 1px border rendered in `rgba(255, 255, 255, 0.08)`.
- **Level 2 (Active/Hover Cards & Popovers):** Translucent `#1e293b` with a fine linear gradient top-to-bottom edge border: `linear-gradient(180deg, rgba(56, 189, 248, 0.3) 0%, rgba(255, 255, 255, 0.03) 100%)`.
- **Level 3 (Modal Dialogs & AI Execution Sheets):** `#111827` overlaid with an ambient colored bloom shadow: `0 20px 48px -12px rgba(10, 15, 29, 0.8), 0 0 24px 0 rgba(56, 189, 248, 0.15)`.

Light sources are directional, entering from the top edge to create sharp, crisp specular highlights on glass panels.

## Shapes
A disciplined, soft radius (`roundedness: 1` — 4px base, 8px for containers, 12px for modal surfaces) delivers a calibrated, instrument-like feel. Micro-elements like tags, badges, and validation pills use a fixed 4px radius to preserve screen real estate and maximize legibility within data-dense curriculum maps. Circular radii are strictly confined to user avatars and binary toggle switches.

## Components

### Buttons
- **Primary (AI Action / Export):** High-contrast vibrant gradient fill (`linear-gradient(135deg, #38bdf8 0%, #2563eb 100%)`), text color `#0a0f1d` (semi-bold), 1px solid `rgba(255, 255, 255, 0.3)` top inset border. Hover creates an electric glow: `box-shadow: 0 0 16px rgba(56, 189, 248, 0.4)`.
- **Secondary (Institutional Review):** Translucent backdrop (`rgba(26, 61, 124, 0.25)`), text `#f8fafc`, 1px border `rgba(56, 189, 248, 0.2)`. Hover background shifts to `rgba(26, 61, 124, 0.45)`.
- **Ghost / Minimal:** Transparent background, text `#94a3b8`, 1px transparent border. Hover transitions to text `#ffffff` with background `rgba(255, 255, 255, 0.05)`.

### Cards & Modules
Cards use frosted glass backing (`rgba(15, 23, 42, 0.75)`, 16px blur) framed by a 1px perimeter line (`rgba(255, 255, 255, 0.08)`). On hover, borders dynamically brighten with an interactive gradient tracking the cursor. Header sections include an integrated code block and accreditation status indicator.

### Input Fields & Selects
Dark recessed surfaces (`rgba(10, 15, 29, 0.85)`) framed by `rgba(255, 255, 255, 0.12)` borders. Typography is Inter 14px with `#f8fafc` value text and `#64748b` placeholder text. Focus state activates an electric cyan hairline border (`#38bdf8`) paired with an ambient `0 0 0 3px rgba(56, 189, 248, 0.15)` glow ring.

### Micro-Badges & Accreditation Tags
- **Bloom Taxonomy Pills:** Compact height (20px), monospaced text indicator prefix (e.g., `L4: ANALYZE`), subtle tinted backgrounds (`rgba(147, 51, 234, 0.12)`), solid border (`rgba(168, 85, 247, 0.3)`), and high-contrast text (`#d8b4fe`).
- **NBA Criteria Counters:** Structured split badges with criterion code on the left (slate background) and compliance metric on the right (emerald/amber background), separated by a hairline divider.

### Matrix Lists & Grids
Syllabus and Outcome mapping lists feature alternating subtle row fills (`transparent` vs `rgba(255, 255, 255, 0.015)`), explicit 1px horizontal dividers (`rgba(255, 255, 255, 0.05)`), and left-border accent markers denoting course learning objective (CLO) to program outcome (PO) alignment strength.

### Checkboxes & Radios
Square boxes with 3px border radius, charcoal slate fill, and an internal cyan glow when selected (`#38bdf8` fill with an embedded SVG white micro-checkmark). Radio buttons retain standard circular forms with a centered 4px glowing cyan pip.